# dynamo-delete-jdd
